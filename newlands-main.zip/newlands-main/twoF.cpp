#include<stdio.h>
#include<math.h>

double f(double a3,double a2,double a1,double a0,double x);
int main(void)
{
    double a,b,res;
    double a3,a2,a1,a0;
    scanf("%lf %lf %lf %lf",&a3,&a2,&a1,&a0);
    scanf("%lf %lf",&a,&b);
    double tmp;
    while(1)
    {
        if(f(a3,a2,a1,a0,a)*f(a3,a2,a1,a0,b) <0){
            if(f(a3,a2,a1,a0,(a+b)/2.0)==0)
            break;
            else{
                if(f(a3,a2,a1,a0,a)*f(a3,a2,a1,a0,(a+b)/2.0) <0){
                    tmp=a;
                    a=(a+b)/2.0;
                    b=(tmp+(tmp+b)/2.0)/2.0;
                }
                else{
                    tmp=(a+b)/2.0;
                    a=(tmp+b)/2.0;
                    b=tmp;
                }
            }
        }
    
    printf("%lf",(a+b)/2.0);
    return 0;
    }
        
}

double f(double a3,double a2,double a1,double a0,double x)
{
    return a3*pow(x,3)+a2*pow(x,2)+a1*x+a0;
}
